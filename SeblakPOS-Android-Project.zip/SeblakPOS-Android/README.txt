SEBLAK POS - Proyek Android

Isi:
- Aplikasi Android WebView yang membuka aplikasi kasir dari assets/index.html.
- Penyimpanan localStorage browser WebView untuk data aplikasi.
- Tidak membutuhkan server web saat aplikasi berjalan.

Cara membuat APK:
1. Buka folder SeblakPOS di Android Studio.
2. Tunggu Gradle Sync selesai (butuh internet pertama kali untuk mengunduh Android Gradle Plugin/SDK jika belum ada).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug tersedia di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- APK belum dikompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia.
- Aplikasi HTML dimasukkan apa adanya; beberapa font/icon eksternal di HTML mungkin memerlukan internet.
- Data localStorage dari Chrome/HTML lama tidak otomatis berpindah ke WebView. Gunakan fitur backup/restore JSON yang ada untuk pemindahan data jika didukung oleh versi aplikasi.
